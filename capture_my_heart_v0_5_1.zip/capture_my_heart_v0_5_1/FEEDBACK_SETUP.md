# 고객 피드백 수집 설정

## 1. 현재 게임에 이미 들어간 것

사용자는 게임에서 다음 위치에서 바로 피드백을 보낼 수 있습니다.

- 타이틀 화면 FEEDBACK
- PAUSE 화면
- Stage Clear 화면
- GAME OVER 화면
- 10 Stage 엔딩

피드백 데이터:

- 재미 점수 1~5
- 난이도
- 다음 스테이지/캐릭터 기대감
- 자유 의견
- Stage / Score / Area / Lives
- 게임 버전 / 화면 크기 / 터치 여부 / 브라우저 식별 문자열

이름·이메일은 요구하지 않습니다.

## 2. Cloudflare D1 연결

프로젝트에 포함된 파일:

- `functions/api/feedback.js`
- `feedback-schema.sql`
- `wrangler.toml.example`

### 순서

1. Cloudflare에 `capture-my-heart-feedback` D1 데이터베이스 생성
2. `feedback-schema.sql` 실행
3. Pages 프로젝트에 D1 바인딩 추가
   - Variable name: `FEEDBACK_DB`
4. 프로젝트 전체를 Pages에 배포
5. 게임에서 FEEDBACK 제출
6. D1의 `game_feedback` 테이블에서 확인

## 3. 자주 볼 지표

초기에는 복잡하게 보지 말고 아래만 봅니다.

- 평균 재미 점수
- `curiosity=yes` 비율
- 난이도 `hard` 비율
- Stage별 피드백 수
- Stage 1 → 3 → 5 → 10 도달률
- Game Over 후 재도전 비율

특히 이 게임은 **다음 캐릭터가 궁금해서 계속 플레이하는지**가 핵심 가설이므로 `curiosity`가 중요한 지표입니다.

## 4. 스팸 대응

현재 API는 공개 베타용 최소 구현입니다.
트래픽이 늘면 다음 단계에서 Cloudflare Turnstile 또는 rate limit을 추가하세요.
