# 광고 수익화 설계 — v0.5

## 광고 위치

게임 흐름을 끊지 않는 두 곳만 사용합니다.

### 전면광고

- Stage 2 완료 → NEXT STAGE
- Stage 4 완료 → NEXT STAGE
- Stage 6 완료 → NEXT STAGE
- Stage 8 완료 → NEXT STAGE

클리어 이미지 감상/돋보기 시간을 먼저 충분히 주고, 사용자가 `NEXT STAGE`를 눌렀을 때만 광고 요청을 보냅니다.

### 보상형 광고

GAME OVER에서 사용자가 직접 선택:

`WATCH AD · LIFE +1`

광고를 끝까지 본 경우에만 LIFE 1을 지급합니다.

## 현재 상태

- Ad Placement API 연결 코드: 준비됨
- Publisher ID: 미설정
- Live Ads: OFF
- Google H5 Games Ads 테스트 파라미터: 지원

## 켜는 방법

`config.js`의 `ADS` 수정:

```js
ENABLED: true,
PUBLISHER_ID: 'ca-pub-실제ID',
TEST_MODE: true
```

Google의 가짜 광고로 지점 테스트 후:

```js
TEST_MODE: false
```

## 왜 플레이 중 광고를 넣지 않는가

라인을 긋는 동안 광고가 뜨면 게임의 긴장 루프를 깨고 오조작/이탈을 유발합니다. 광고는 자연스러운 레벨 전환과 사용자가 선택한 보상형 지점으로 제한합니다.

## 수익 관점에서 중요한 리스크

현재 게임 아트에는 성적으로 암시적인 팬서비스 요소가 있습니다. Google Publisher Restrictions에서 성적으로 자극적이거나 성적 흥분을 목적으로 한 콘텐츠는 광고 수요가 제한될 수 있습니다.

따라서 출시 전략은 두 단계가 현실적입니다.

1. 현재 아트로 **재미/리텐션 공개 베타**
2. 지표가 나오면 광고 심사용으로 수위를 낮춘 `Ad-Safe Art Pack`을 별도 제작하여 A/B 검토

연령 확인만으로 광고 제한이 자동 해소되지는 않습니다.
