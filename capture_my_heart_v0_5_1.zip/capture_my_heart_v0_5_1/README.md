# Capture My Heart! Territory Panic — v0.5 Feedback Beta

## 이번 버전 핵심

- v0.4 게임성 유지: 1.50× 카메라, 우측 하단 미니맵, Stage Clear 돋보기
- Danger BGM 전환 OFF 유지
- **인게임 피드백 UI 추가**
  - 타이틀 FEEDBACK
  - 일시정지 FEEDBACK
  - Stage Clear `이 판 피드백`
  - Game Over `한줄 피드백`
  - 엔딩 FEEDBACK
- 피드백 항목
  - 재미 1~5
  - 난이도: 쉬움 / 딱 좋음 / 어려움
  - 다음 캐릭터 때문에 계속 하고 싶은지
  - 자유 의견 500자
- 게임 버전, Stage, Score, Area, 화면 크기 등 테스트 맥락 자동 첨부
- 네트워크 실패 시 브라우저에 임시 큐 저장 후 다음 접속 때 재전송 시도
- **Cloudflare Pages Functions + D1용 피드백 수집 API 코드 포함**
- H5 Games Ads 연결 구조 강화
  - 전면광고 후보 지점: Stage 2 / 4 / 6 / 8 완료 후 `NEXT STAGE`를 누른 뒤
  - 보상형 광고 후보: GAME OVER → LIFE +1
  - 테스트 모드 파라미터 지원
  - 현재는 Publisher ID가 비어 있어 광고 OFF

## 실행

### 가장 간단하게
`게임실행.bat` 더블클릭

- v0.5.1에서 Windows BAT의 따옴표 처리 문제를 수정했습니다.
- `py`/`python`이 실제로 실행 가능한지 확인한 뒤 로컬 서버를 시작합니다.
- Python이 없으면 자동으로 `index.html` 직접 실행으로 전환합니다.
- 서버 없이 무조건 바로 열려면 `게임바로실행.bat`을 사용하세요.

- Python이 있으면 로컬 서버를 자동으로 열고 `http://localhost:8080` 실행
- Python이 없으면 `index.html`을 직접 엽니다.

## 피드백을 실제로 모으려면

현재 `config.js`의 피드백 주소는 `/api/feedback`입니다.
Cloudflare Pages에 배포하고 D1의 `FEEDBACK_DB` 바인딩을 연결하면 동봉된 `functions/api/feedback.js`가 자동으로 JSON 피드백을 저장합니다.

자세한 설정은 `FEEDBACK_SETUP.md` 참고.

## 실제 광고를 켜려면

`config.js`:

```js
ADS: {
  ENABLED: true,
  PUBLISHER_ID: 'ca-pub-xxxxxxxxxxxxxxxx',
  TEST_MODE: true
}
```

먼저 H5 Games Ads 승인 및 Publisher ID가 필요합니다. 테스트가 끝난 뒤 `TEST_MODE:false`로 전환합니다.
자세한 내용은 `MONETIZATION.md` 참고.

## 중요

현재 히로인 일러스트는 팬서비스 강도가 높습니다. 실제 광고 네트워크 심사/광고 수요는 별도 검토가 필요합니다. 광고 승인 전에는 공개 플레이테스트와 피드백 수집을 먼저 권장합니다.
