# v0.5 Test Report

## 정적/문법 검사

PASS

- `config.js` — Node syntax check PASS
- `ads.js` — PASS
- `feedback.js` — PASS
- `game.js` — PASS
- `sw.js` — PASS
- `functions/api/feedback.js` — PASS

## 피드백 API 단위 검사

PASS

Cloudflare Pages Function을 mock D1 환경에서 직접 호출:

- same-origin POST JSON 허용
- `fun=5`, Stage/Score/Area 등 입력 검증
- D1 INSERT bind 16개 생성
- HTTP 200 `{"ok":true}` 반환

## UI 연결 확인

코드 레벨 연결 확인:

- Title → FEEDBACK
- Pause → FEEDBACK
- Stage Clear → `이 판 피드백`
- Game Over → `한줄 피드백`
- Ending → FEEDBACK
- Stage Clear 돋보기 유지
- NEXT STAGE 전에 클리어 이미지 감상 구간 유지

## 광고 연결 확인

- H5 Games Ads script loader 유지
- Publisher ID 없으면 광고 요청하지 않음
- Google test parameter `data-adbreak-test=on` 지원
- Interstitial planned stages: 2 / 4 / 6 / 8
- Rewarded LIFE +1 path 유지
- Danger BGM OFF 유지

## 제한

이 환경에서 Chromium headless 렌더 smoke test는 프로세스 종료가 지연되어 완료 판정하지 않았습니다. 따라서 실제 PC/모바일에서 v0.5 UI 클릭 동선은 공개 전 한 번 수동 검증해야 합니다.


## v0.5.1 Launcher Hotfix

- 기존 `start ... cmd /k` 내부의 중첩 따옴표 문제 제거
- `py -3 --version` / `python -c "import sys"`로 실제 실행 가능 여부 확인
- Python 미설치 시 `index.html` 자동 직접 실행
- `게임바로실행.bat` 추가
- 정적 검토 PASS (Windows 런타임 실기기 검증은 사용자 PC에서 필요)
