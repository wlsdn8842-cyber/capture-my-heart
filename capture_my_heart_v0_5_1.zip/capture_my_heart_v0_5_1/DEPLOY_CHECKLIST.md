# v0.5 공개 베타 배포 체크리스트

- [ ] 소유 도메인/Pages URL 확정
- [ ] HTTPS에서 게임 실행
- [ ] `feedback-schema.sql` D1 적용
- [ ] Pages D1 binding `FEEDBACK_DB` 연결
- [ ] 게임 피드백 1건 제출 → D1 저장 확인
- [ ] PC Chrome/Edge 플레이 확인
- [ ] 모바일 가로모드 플레이 확인
- [ ] NEW GAME / CONTINUE / LOAD SAVE 확인
- [ ] Stage Clear → 돋보기 → NEXT STAGE 확인
- [ ] 10 Stage 엔딩 확인
- [ ] 광고 승인 전 `ADS.ENABLED=false` 유지
- [ ] H5 Games Ads 승인/Publisher ID 확보 후 `TEST_MODE=true`로 테스트
- [ ] 실제 광고 전 개인정보처리방침 업데이트
- [ ] 현재 팬서비스 아트 광고 정책 검토
