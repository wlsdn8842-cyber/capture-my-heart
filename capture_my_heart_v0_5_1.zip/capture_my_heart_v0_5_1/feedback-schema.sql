CREATE TABLE IF NOT EXISTS game_feedback (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  version TEXT,
  session_id TEXT,
  source TEXT,
  stage INTEGER NOT NULL DEFAULT 0,
  score INTEGER NOT NULL DEFAULT 0,
  area REAL NOT NULL DEFAULT 0,
  lives INTEGER NOT NULL DEFAULT 0,
  fun INTEGER NOT NULL,
  difficulty TEXT,
  curiosity TEXT,
  comment TEXT,
  viewport TEXT,
  touch INTEGER NOT NULL DEFAULT 0,
  user_agent TEXT
);

CREATE INDEX IF NOT EXISTS idx_game_feedback_created_at ON game_feedback(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_game_feedback_stage ON game_feedback(stage);
