const json = (body, status = 200) => new Response(JSON.stringify(body), {
  status,
  headers: {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store'
  }
});

function cleanString(v, max = 240) {
  return typeof v === 'string' ? v.trim().slice(0, max) : '';
}

export async function onRequestPost(context) {
  const { request, env } = context;
  if (!env.FEEDBACK_DB) return json({ ok: false, error: 'feedback_db_not_bound' }, 503);

  const requestUrl = new URL(request.url);
  const origin = request.headers.get('origin');
  if (origin) {
    try {
      if (new URL(origin).host !== requestUrl.host) return json({ ok: false, error: 'origin_not_allowed' }, 403);
    } catch (_) {
      return json({ ok: false, error: 'bad_origin' }, 400);
    }
  }

  const type = request.headers.get('content-type') || '';
  if (!type.includes('application/json')) return json({ ok: false, error: 'json_required' }, 415);

  let d;
  try { d = await request.json(); } catch (_) { return json({ ok: false, error: 'invalid_json' }, 400); }

  const id = cleanString(d.id, 80);
  const fun = Number(d.fun);
  const stage = Math.max(0, Math.min(10, Number(d.stage) || 0));
  const area = Math.max(0, Math.min(100, Number(d.area) || 0));
  const score = Math.max(0, Math.floor(Number(d.score) || 0));
  const lives = Math.max(0, Math.min(20, Math.floor(Number(d.lives) || 0)));
  const allowedDifficulty = new Set(['easy', 'good', 'hard']);
  const allowedCuriosity = new Set(['yes', 'maybe', 'no']);

  if (!id || !Number.isFinite(fun) || fun < 1 || fun > 5) {
    return json({ ok: false, error: 'invalid_feedback' }, 400);
  }

  const row = {
    id,
    created_at: cleanString(d.created_at, 40) || new Date().toISOString(),
    version: cleanString(d.version, 30),
    session_id: cleanString(d.session_id, 80),
    source: cleanString(d.source, 40),
    stage,
    score,
    area,
    lives,
    fun: Math.round(fun),
    difficulty: allowedDifficulty.has(d.difficulty) ? d.difficulty : null,
    curiosity: allowedCuriosity.has(d.curiosity) ? d.curiosity : null,
    comment: cleanString(d.comment, 500),
    viewport: cleanString(d.viewport, 30),
    touch: d.touch ? 1 : 0,
    user_agent: cleanString(d.user_agent, 240)
  };

  try {
    await env.FEEDBACK_DB.prepare(`
      INSERT OR IGNORE INTO game_feedback
      (id, created_at, version, session_id, source, stage, score, area, lives, fun, difficulty, curiosity, comment, viewport, touch, user_agent)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      row.id, row.created_at, row.version, row.session_id, row.source,
      row.stage, row.score, row.area, row.lives, row.fun,
      row.difficulty, row.curiosity, row.comment, row.viewport, row.touch, row.user_agent
    ).run();
    return json({ ok: true });
  } catch (e) {
    return json({ ok: false, error: 'db_error' }, 500);
  }
}

export async function onRequestGet() {
  return json({ ok: false, error: 'method_not_allowed' }, 405);
}
