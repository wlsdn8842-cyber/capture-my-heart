(() => {
  const cfg = window.CMH_CONFIG?.ADS || {};
  let initialized = false;
  let lastInterstitialAt = 0;
  let wasMuted = false;

  function enabled(){ return !!(cfg.ENABLED && cfg.PUBLISHER_ID); }

  function loadGoogleScript() {
    return new Promise((resolve) => {
      if (!enabled()) return resolve(false);
      if (window.adBreak && window.adConfig) return resolve(true);
      window.adsbygoogle = window.adsbygoogle || [];
      window.adBreak = window.adConfig = function(o) { window.adsbygoogle.push(o); };
      const s = document.createElement('script');
      s.async = true;
      s.crossOrigin = 'anonymous';
      s.dataset.adClient = cfg.PUBLISHER_ID;
      s.dataset.adFrequencyHint = cfg.FREQUENCY_HINT || '120s';
      if (cfg.TEST_MODE) s.dataset.adbreakTest = 'on';
      s.src = `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${encodeURIComponent(cfg.PUBLISHER_ID)}`;
      s.onload = () => resolve(true);
      s.onerror = () => resolve(false);
      document.head.appendChild(s);
    });
  }

  async function init() {
    if (initialized) return;
    initialized = true;
    const ok = await loadGoogleScript();
    if (ok && window.adConfig) {
      try { window.adConfig({ preloadAdBreaks: 'on', sound: 'on' }); } catch (_) {}
    }
  }

  function beforeAd() {
    wasMuted = window.CMH_GAME?.audio?.muted || false;
    window.CMH_GAME?.pauseForAd?.();
    window.CMH_GAME?.audio?.setMuted?.(true, true);
  }

  function afterAd() {
    window.CMH_GAME?.audio?.setMuted?.(wasMuted, true);
    window.CMH_GAME?.resumeAfterAd?.();
  }

  function showInterstitial(name = 'stage_transition', done = () => {}) {
    const now = Date.now();
    const minMs = (cfg.MIN_SECONDS_BETWEEN_INTERSTITIALS || 120) * 1000;
    if (!enabled() || !window.adBreak || (now - lastInterstitialAt) < minMs) {
      done({status: 'skipped'});
      return;
    }
    lastInterstitialAt = now;
    try {
      window.adBreak({
        type: 'next',
        name,
        beforeAd,
        afterAd,
        adBreakDone: (info) => done(info || {status: 'done'})
      });
    } catch (e) {
      console.warn('Interstitial failed', e);
      done({status: 'error'});
    }
  }

  function showRewardedLife() {
    return new Promise((resolve) => {
      if (!enabled() || !window.adBreak) return resolve(false);
      let rewarded = false;
      try {
        window.adBreak({
          type: 'reward',
          name: 'new_life_reward',
          beforeAd,
          afterAd,
          beforeReward: (showAdFn) => window.CMH_GAME?.showRewardPrompt?.(showAdFn),
          adDismissed: () => { rewarded = false; },
          adViewed: () => { rewarded = true; },
          adBreakDone: () => resolve(rewarded)
        });
      } catch (e) {
        console.warn('Rewarded ad failed', e);
        resolve(false);
      }
    });
  }

  window.CMH_ADS = {
    init,
    showInterstitial,
    showRewardedLife,
    enabled,
    testMode: () => !!cfg.TEST_MODE
  };
})();
