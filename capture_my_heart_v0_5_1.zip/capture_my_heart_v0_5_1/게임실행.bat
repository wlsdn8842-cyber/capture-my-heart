@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Capture My Heart Launcher

echo [Capture My Heart] Starting...

rem 1) Prefer the Windows Python launcher when it is actually usable.
py -3 --version >nul 2>&1
if not errorlevel 1 goto run_py

rem 2) Fall back to python.exe when it is actually usable.
python -c "import sys" >nul 2>&1
if not errorlevel 1 goto run_python

rem 3) No Python: direct-open mode still lets you play locally.
echo [Capture My Heart] Python was not found.
echo [Capture My Heart] Opening index.html directly.
start "" "%~dp0index.html"
exit /b 0

:run_py
echo [Capture My Heart] Local server: http://localhost:8080
start "CMH Local Server" cmd /k "py -3 -m http.server 8080"
timeout /t 2 /nobreak >nul
start "" "http://localhost:8080/"
exit /b 0

:run_python
echo [Capture My Heart] Local server: http://localhost:8080
start "CMH Local Server" cmd /k "python -m http.server 8080"
timeout /t 2 /nobreak >nul
start "" "http://localhost:8080/"
exit /b 0
