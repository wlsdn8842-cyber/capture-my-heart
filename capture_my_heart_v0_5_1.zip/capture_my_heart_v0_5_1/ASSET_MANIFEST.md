# Capture My Heart! v0.5 Asset Manifest

## Images
- `assets/images/title.webp` — title / landing art
- `assets/images/stage01.webp` ~ `stage10.webp` — 10 stage artwork
- `assets/images/icon-192.png`, `icon-512.png` — PWA icons

## Audio
- `main.mp3` — title / Stage 9 fallback
- `stages_1_4.mp3` — Stage 1~4
- `stages_5_8.mp3` — Stage 5~8
- `stage10.mp3` — Stage 10
- `clear.mp3` — stage clear jingle
- `perfect.mp3` — perfect jingle
- `danger.mp3` — retained asset; automatic danger switching currently OFF

## Gameplay presentation
- Camera zoom: 1.50×
- Minimap: bottom-right, reduced size
- Stage clear art magnifier: enabled
- Feedback UI/API: enabled
- Live ads: disabled until Publisher ID is configured
