(() => {
'use strict';

const $ = (s) => document.querySelector(s);
const titleScreen = $('#titleScreen');
const gameScreen = $('#gameScreen');
const modalLayer = $('#modalLayer');
const canvas = $('#gameCanvas');
const ctx = canvas.getContext('2d', { alpha: false });
const miniMap = $('#miniMapCanvas');
const miniCtx = miniMap?.getContext('2d', { alpha: false });
const W = canvas.width, H = canvas.height;
const worldCanvas = document.createElement('canvas'); worldCanvas.width = W; worldCanvas.height = H;
const worldCtx = worldCanvas.getContext('2d', { alpha: false });
const CELL = 8, GW = W / CELL, GH = H / CELL;
const UNCLAIMED = 0, CLAIMED = 1, TRAIL = 2;
const grid = new Uint8Array(GW * GH);
const fogCanvas = document.createElement('canvas'); fogCanvas.width = W; fogCanvas.height = H;
const fogCtx = fogCanvas.getContext('2d');
const safeCanvas = document.createElement('canvas'); safeCanvas.width = W; safeCanvas.height = H;
const safeCtx = safeCanvas.getContext('2d');
const imageCache = new Map();
const SAVE_PREFIX = 'cmh.save.';
const GLOBAL_KEY = 'cmh.global';
const SETTINGS_KEY = 'cmh.settings';

const STAGES = [null,
  {name:'Maid Cafe',     music:'assets/audio/stages_1_4.mp3', speed:84,  shots:0,    minions:0, chase:0.00, timer:180, hue:'#ff6aaa'},
  {name:'Racing Girl',   music:'assets/audio/stages_1_4.mp3', speed:91,  shots:3400, minions:0, chase:0.03, timer:175, hue:'#ff6a8b'},
  {name:'Office Lady',   music:'assets/audio/stages_1_4.mp3', speed:98,  shots:3100, minions:0, chase:0.05, timer:170, hue:'#62c6ff'},
  {name:'Miko',          music:'assets/audio/stages_1_4.mp3', speed:105, shots:2800, minions:0, chase:0.06, timer:165, hue:'#ff5f70'},
  {name:'Idol',          music:'assets/audio/stages_5_8.mp3', speed:112, shots:2500, minions:1, chase:0.08, timer:160, hue:'#ff5fcf'},
  {name:'Resort',        music:'assets/audio/stages_5_8.mp3', speed:118, shots:2300, minions:1, chase:0.10, timer:155, hue:'#45dcff'},
  {name:'Wizard',        music:'assets/audio/stages_5_8.mp3', speed:125, shots:2100, minions:1, chase:0.14, timer:150, hue:'#a768ff'},
  {name:'Gothic',        music:'assets/audio/stages_5_8.mp3', speed:132, shots:1900, minions:2, chase:0.18, timer:145, hue:'#e44879'},
  {name:'Kung-fu',       music:'assets/audio/main.mp3',       speed:140, shots:1700, minions:2, chase:0.22, timer:140, hue:'#ffb04e'},
  {name:'Final Queen',   music:'assets/audio/stage10.mp3',    speed:148, shots:1450, minions:3, chase:0.26, timer:135, hue:'#ffd66a'}
];

const state = {
  mode:'title', stage:1, score:0, lives:3, timeLeft:180, slot:1,
  player:{x:Math.floor(GW/2), y:1, drawing:false, trailStart:{x:Math.floor(GW/2),y:1}, trailPath:[]},
  enemies:[], projectiles:[], items:[], area:0, lastArea:0, clearMilestone:0,
  speedBoostUntil:0, freezeUntil:0, slowUntil:0, shield:0,
  paused:false, adPaused:false, frameId:0, lastTs:0, moveAcc:0, timerAcc:0,
  shotAcc:0, continueCredits:1, currentImage:null, stageStartedAt:0,
  unlocked:new Set(), tutorialShown:localStorage.getItem('cmh.tutorial') === '1'
};

function defaultSettings(){ return {volume:0.68, muted:false, sfx:true}; }
function loadSettings(){ try{return {...defaultSettings(),...JSON.parse(localStorage.getItem(SETTINGS_KEY)||'{}')}}catch{return defaultSettings()} }
function saveSettings(){ localStorage.setItem(SETTINGS_KEY, JSON.stringify(audio.settings)); }

class AudioManager {
  constructor(){
    this.settings = loadSettings();
    this.base = new Audio(); this.base.loop = true; this.base.preload = 'auto';
    this.danger = new Audio('assets/audio/danger.mp3'); this.danger.loop = true; this.danger.preload = 'auto';
    this.jingle = new Audio(); this.jingle.preload = 'auto';
    this.currentBase = '';
    this.muted = this.settings.muted;
    this.dangerOn = false;
    this.apply();
  }
  apply(){
    const m=this.muted; const v=this.settings.volume;
    this.base.muted=m; this.danger.muted=m; this.jingle.muted=m;
    this.base.volume=this.dangerOn?Math.min(.18,v*.3):v;
    this.danger.volume=this.dangerOn?v:0;
    this.jingle.volume=v;
  }
  setMuted(value, temporary=false){ this.muted=!!value; if(!temporary){this.settings.muted=this.muted; saveSettings();} this.apply(); updateMusicLabel(); }
  setVolume(v){ this.settings.volume=Math.max(0,Math.min(1,Number(v))); saveSettings(); this.apply(); updateMusicLabel(); }
  async playBase(src, restart=false){
    if(!src) return;
    this.jingle.pause();
    if(this.currentBase!==src){ this.base.pause(); this.base.src=src; this.currentBase=src; restart=true; }
    if(restart) this.base.currentTime=0;
    this.apply();
    try{ await this.base.play(); }catch(_){ }
  }
  async playTitle(){ await this.playBase('assets/audio/main.mp3'); this.setDanger(false); }
  setDanger(on){
    // v0.3: danger music switching is temporarily disabled for a calmer, more focused play loop.
    if(window.CMH_CONFIG?.GAMEPLAY?.DANGER_BGM_ENABLED===false) on=false;
    on=!!on; if(on===this.dangerOn) return; this.dangerOn=on;
    if(on){ try{this.danger.play()}catch(_){} } else { this.danger.pause(); }
    this.apply(); updateMusicLabel();
  }
  async playJingle(src){
    this.setDanger(false); this.base.pause(); this.jingle.src=src; this.jingle.currentTime=0; this.apply();
    try{ await this.jingle.play(); }catch(_){}
  }
  resumeBase(){ this.jingle.pause(); if(this.currentBase){try{this.base.play()}catch(_){}} }
  pauseAll(){ this.base.pause(); this.danger.pause(); this.jingle.pause(); }
  beep(freq=440,duration=.08,type='sine',gain=.035){
    if(!this.settings.sfx || this.muted) return;
    try{
      const ac = AudioManager._ac || (AudioManager._ac = new (window.AudioContext||window.webkitAudioContext)());
      const o=ac.createOscillator(), g=ac.createGain(); o.type=type; o.frequency.value=freq; g.gain.value=gain; o.connect(g);g.connect(ac.destination);o.start();o.stop(ac.currentTime+duration);
    }catch(_){ }
  }
}
const audio = new AudioManager();

function initAnalytics(){
  const id=window.CMH_CONFIG?.ANALYTICS?.GA_MEASUREMENT_ID;
  if(!id) return;
  const s=document.createElement('script');s.async=true;s.src=`https://www.googletagmanager.com/gtag/js?id=${encodeURIComponent(id)}`;document.head.appendChild(s);
  window.dataLayer=window.dataLayer||[];window.gtag=function(){dataLayer.push(arguments)};gtag('js',new Date());gtag('config',id,{anonymize_ip:true});
}
function track(name,params={}){ try{window.gtag?.('event',name,params)}catch(_){} }

function idx(x,y){return y*GW+x}
function inGrid(x,y){return x>=0&&y>=0&&x<GW&&y<GH}
function getCell(x,y){return inGrid(x,y)?grid[idx(x,y)]:CLAIMED}
function setCell(x,y,v){if(inGrid(x,y))grid[idx(x,y)]=v}
function cellAtPixel(x,y){return {x:Math.max(0,Math.min(GW-1,Math.floor(x/CELL))),y:Math.max(0,Math.min(GH-1,Math.floor(y/CELL)))}}
function dist(ax,ay,bx,by){return Math.hypot(ax-bx,ay-by)}
function clamp(v,a,b){return Math.max(a,Math.min(b,v))}
function fmtScore(n){return Math.max(0,Math.floor(n)).toLocaleString('en-US')}
function now(){return performance.now()}

function loadImage(src){
  if(imageCache.has(src)) return imageCache.get(src);
  const p=new Promise((res,rej)=>{const im=new Image();im.onload=()=>res(im);im.onerror=rej;im.src=src;});imageCache.set(src,p);return p;
}
function stageSrc(n){return `assets/images/stage${String(n).padStart(2,'0')}.webp`}

function globalData(){
  try{return JSON.parse(localStorage.getItem(GLOBAL_KEY)||'{}')}catch{return {}}
}
function saveGlobal(patch={}){
  const g={bestScore:0,unlockedStages:[],...globalData(),...patch};
  const union=new Set([...(g.unlockedStages||[]),...state.unlocked]);g.unlockedStages=[...union].sort((a,b)=>a-b);
  g.bestScore=Math.max(g.bestScore||0,state.score||0);localStorage.setItem(GLOBAL_KEY,JSON.stringify(g));return g;
}
function loadUnlocked(){ const g=globalData(); state.unlocked=new Set(g.unlockedStages||[]); }
function unlockStage(n){state.unlocked.add(n);saveGlobal();}

function saveToSlot(slot=state.slot, manual=false){
  state.slot=slot;
  const data={version:1,slot,stage:state.stage,score:state.score,lives:Math.max(1,state.lives),updatedAt:Date.now(),unlocked:[...state.unlocked],completed:state.stage>10};
  localStorage.setItem(SAVE_PREFIX+slot,JSON.stringify(data));saveGlobal();
  if(manual) toast(`SAVE SLOT ${slot} 저장 완료`,false,1300);
  refreshTitle();
  return data;
}
function readSlot(slot){try{return JSON.parse(localStorage.getItem(SAVE_PREFIX+slot)||'null')}catch{return null}}
function recentSave(){return [1,2,3].map(readSlot).filter(Boolean).sort((a,b)=>(b.updatedAt||0)-(a.updatedAt||0))[0]||null}
function loadSaveData(data){
  if(!data)return;
  state.slot=data.slot||1;state.stage=clamp(data.stage||1,1,10);state.score=data.score||0;state.lives=data.lives||3;
  state.unlocked=new Set([...(globalData().unlockedStages||[]),...(data.unlocked||[])]);state.continueCredits=1;
  startStage(state.stage,true);
}

function refreshTitle(){
  const r=recentSave(), c=$('#continueBtn'), summary=$('#saveSummary');
  c.disabled=!r;
  summary.classList.toggle('no-save',!r);
  if(r){
    const d=new Date(r.updatedAt);
    summary.innerHTML=`<strong>💾 SAVE DATA</strong><span>SLOT ${r.slot} · Stage ${r.stage}</span><span>${fmtScore(r.score)} pts</span><span>${d.toLocaleString()}</span>`;
  } else {
    summary.innerHTML='<strong>💾 NO SAVE DATA</strong><span>NEW GAME으로 시작하세요</span>';
  }
}

function showTitle(){
  state.mode='title';state.paused=false;audio.setDanger(false);gameScreen.classList.add('hidden');titleScreen.classList.remove('hidden');closeModal();refreshTitle();audio.playTitle();
}
function showGame(){titleScreen.classList.add('hidden');gameScreen.classList.remove('hidden')}

function openModal(html,extraClass=''){ modalLayer.innerHTML=`<div class="modal-card ${extraClass}">${html}</div>`; modalLayer.classList.remove('hidden'); }
function closeModal(){modalLayer.classList.add('hidden');modalLayer.innerHTML=''}
function toast(text,danger=false,ms=1600){const el=$('#statusToast');el.textContent=text;el.classList.toggle('toast-danger',danger);el.classList.remove('hidden');clearTimeout(toast._t);toast._t=setTimeout(()=>el.classList.add('hidden'),ms)}

function showSlotPicker(mode){
  state.paused=state.mode==='playing';
  const slots=[1,2,3].map(s=>{const d=readSlot(s);return `<button class="save-slot" data-slot="${s}"><strong>SLOT ${s}</strong><small>${d?`Stage ${d.stage} · ${fmtScore(d.score)} pts · ${new Date(d.updatedAt).toLocaleString()}`:'EMPTY'}</small></button>`}).join('');
  openModal(`<h2>${mode==='new'?'NEW GAME':'LOAD SAVE'}</h2><div class="slot-grid">${slots}</div><div style="margin-top:14px"><button class="btn tertiary" id="slotCancel">CANCEL</button></div>`);
  modalLayer.querySelectorAll('.save-slot').forEach(btn=>btn.onclick=()=>{
    const s=Number(btn.dataset.slot), existing=readSlot(s);
    if(mode==='new'){
      if(existing&&!confirm(`SLOT ${s}의 기존 저장을 덮어쓸까요?`))return;
      state.slot=s;state.stage=1;state.score=0;state.lives=3;state.continueCredits=1;loadUnlocked();saveToSlot(s);closeModal();startStage(1,false);
    } else if(existing){closeModal();loadSaveData(existing)}
  });
  $('#slotCancel').onclick=()=>{closeModal(); if(state.mode==='playing')state.paused=false};
}

function showHowTo(){
  openModal(`<h2>HOW TO PLAY</h2><div class="howto-list">
    <p><span class="kbd">WASD / ↑↓←→</span> 안전영역 이동</p>
    <p><span class="kbd">SPACE</span> 안전영역에서 바깥으로 선 긋기 시작. 시작 후에는 SPACE를 떼어도 선이 유지됩니다.</p>
    <p>선을 다시 안전영역에 연결하면 <b>보스가 없는 쪽</b>을 점령하고 이미지가 공개됩니다.</p>
    <p>선을 잘못 그었을 때는 <b>방금 지나온 경로를 그대로 되짚어</b> 돌아가면 라인을 되감을 수 있습니다. 단, 이전 라인을 옆에서 가로질러 교차하면 MISS입니다.</p>
    <p><b>80%</b> 클리어 / <b>90%</b> 보너스 / <b>99%+</b> PERFECT 판정.</p>
    <p>선을 그리는 동안 보스·적탄이 선 또는 플레이어에 닿으면 LIFE를 잃습니다.</p>
    <p>모바일은 화면 아래 방향키와 CAPTURE 버튼을 사용합니다.</p>
  </div><button id="howClose" class="btn primary">OK</button>`);$('#howClose').onclick=closeModal;
}

function showGallery(){
  const unlocked=new Set(globalData().unlockedStages||[]);
  const cards=[];for(let i=1;i<=10;i++){const ok=unlocked.has(i);cards.push(`<div class="gallery-card ${ok?'':'locked'}" data-stage="${i}"><img src="${stageSrc(i)}" alt="Stage ${i}">${ok?'':'<div class="lock">🔒</div>'}<div class="caption">Stage ${i} · ${STAGES[i].name}</div></div>`)}
  openModal(`<h2>♡ GALLERY</h2><p class="muted">80% 이상 클리어한 스테이지가 해금됩니다.</p><div class="gallery-grid">${cards.join('')}</div><div style="margin-top:14px"><button id="galleryClose" class="btn primary">CLOSE</button></div>`);
  modalLayer.querySelectorAll('.gallery-card:not(.locked)').forEach(c=>c.onclick=()=>{const i=Number(c.dataset.stage);openModal(`<h2>Stage ${i} · ${STAGES[i].name}</h2><img class="ending-art" src="${stageSrc(i)}" alt="stage art"><div style="margin-top:12px"><button id="artBack" class="btn primary">BACK</button></div>`);$('#artBack').onclick=showGallery});
  $('#galleryClose').onclick=closeModal;
}

function showSettings(){
  const s=audio.settings;
  openModal(`<h2>⚙ SETTINGS</h2><div class="settings-grid">
    <div class="setting-line"><label>BGM / SFX</label><input id="volRange" type="range" min="0" max="1" step="0.01" value="${s.volume}"><span id="volPct">${Math.round(s.volume*100)}%</span></div>
    <div class="toggle"><span>Mute</span><input id="muteCheck" type="checkbox" ${audio.muted?'checked':''}></div>
    <div class="toggle"><span>Simple SFX</span><input id="sfxCheck" type="checkbox" ${s.sfx?'checked':''}></div>
  </div><div style="margin-top:16px"><button id="settingsClose" class="btn primary">CLOSE</button></div>`);
  $('#volRange').oninput=e=>{audio.setVolume(e.target.value);$('#volPct').textContent=`${Math.round(e.target.value*100)}%`};
  $('#muteCheck').onchange=e=>audio.setMuted(e.target.checked);
  $('#sfxCheck').onchange=e=>{audio.settings.sfx=e.target.checked;saveSettings()};
  $('#settingsClose').onclick=closeModal;
}

function showPause(){
  if(state.mode!=='playing')return;state.paused=true;
  openModal(`<h2>PAUSED</h2><div class="slot-grid">
    <button id="resumeBtn" class="btn primary">RESUME</button>
    <button id="saveBtn" class="btn secondary">SAVE CHECKPOINT · SLOT ${state.slot}</button>
    <button id="pauseSettings" class="btn tertiary">SETTINGS</button>
    <button id="pauseFeedback" class="btn tertiary">💬 FEEDBACK</button>
    <button id="quitBtn" class="btn tertiary">TITLE</button>
  </div><p class="muted" style="font-size:.78rem">저장은 현재 Stage 시작 지점 기준 체크포인트입니다. 불러오면 해당 Stage를 처음부터 다시 시작합니다.</p>`);
  $('#resumeBtn').onclick=()=>{closeModal();state.paused=false;audio.resumeBase()};
  $('#saveBtn').onclick=()=>saveToSlot(state.slot,true);
  $('#pauseSettings').onclick=showSettings;
  $('#pauseFeedback').onclick=()=>window.CMH_FEEDBACK?.show?.('pause');
  $('#quitBtn').onclick=()=>{saveToSlot(state.slot);showTitle()};
}

function rebuildVisualLayers(){
  fogCtx.clearRect(0,0,W,H);fogCtx.fillStyle='rgba(4,3,10,.93)';fogCtx.fillRect(0,0,W,H);
  safeCtx.clearRect(0,0,W,H);
  safeCtx.fillStyle='rgba(54,222,255,.18)';safeCtx.strokeStyle='rgba(83,239,255,.9)';safeCtx.lineWidth=1;
  for(let y=0;y<GH;y++)for(let x=0;x<GW;x++){
    if(getCell(x,y)===CLAIMED){fogCtx.clearRect(x*CELL,y*CELL,CELL,CELL);let edge=false;for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]])if(getCell(x+dx,y+dy)===UNCLAIMED){edge=true;break}if(edge){safeCtx.fillRect(x*CELL,y*CELL,CELL,CELL);safeCtx.strokeRect(x*CELL+.5,y*CELL+.5,CELL-1,CELL-1)}}
  }
}

function initGrid(){
  grid.fill(UNCLAIMED);
  for(let x=0;x<GW;x++){setCell(x,0,CLAIMED);setCell(x,1,CLAIMED);setCell(x,GH-1,CLAIMED);setCell(x,GH-2,CLAIMED)}
  for(let y=0;y<GH;y++){setCell(0,y,CLAIMED);setCell(1,y,CLAIMED);setCell(GW-1,y,CLAIMED);setCell(GW-2,y,CLAIMED)}
  state.player={x:Math.floor(GW/2),y:1,drawing:false,trailStart:{x:Math.floor(GW/2),y:1},trailPath:[]};
  state.area=0;state.lastArea=0;rebuildVisualLayers();
}

function randomUnclaimedCell(minFromPlayer=10){
  for(let i=0;i<500;i++){const x=3+Math.floor(Math.random()*(GW-6)),y=3+Math.floor(Math.random()*(GH-6));if(getCell(x,y)===UNCLAIMED&&dist(x,y,state.player.x,state.player.y)>minFromPlayer)return{x,y}}
  return{x:Math.floor(GW/2),y:Math.floor(GH/2)};
}
function spawnEnemies(){
  state.enemies=[];const cfg=STAGES[state.stage];
  const count=1+cfg.minions;for(let i=0;i<count;i++){const c=randomUnclaimedCell(16);const ang=Math.random()*Math.PI*2;const speed=cfg.speed*(i?0.82:1);state.enemies.push({x:(c.x+.5)*CELL,y:(c.y+.5)*CELL,vx:Math.cos(ang)*speed,vy:Math.sin(ang)*speed,speed,r:i?7:11,isBoss:i===0,chase:cfg.chase*(i?1.25:1),shotTimer:cfg.shots?Math.random()*cfg.shots:Infinity})}
}

async function startStage(n,fromSave=false){
  state.stage=clamp(n,1,10);state.mode='loading';showGame();closeModal();state.paused=true;updateHUD();toast(`STAGE ${state.stage} · ${STAGES[state.stage].name}`);
  try{state.currentImage=await loadImage(stageSrc(state.stage))}catch(e){console.error(e);alert('Stage image load failed');return showTitle()}
  initGrid();spawnEnemies();state.projectiles=[];state.items=[];state.clearMilestone=0;state.timeLeft=STAGES[state.stage].timer;state.shotAcc=0;state.speedBoostUntil=0;state.freezeUntil=0;state.slowUntil=0;state.shield=0;state.stageStartedAt=Date.now();state.mode='playing';state.paused=false;state.lastTs=performance.now();state.moveAcc=0;state.timerAcc=0;
  audio.playBase(STAGES[state.stage].music,true);audio.setDanger(false);saveToSlot(state.slot);
  track('stage_start',{stage:state.stage,from_save:!!fromSave});
  preloadNext();
  if(state.stage===1&&!state.tutorialShown){state.paused=true;$('#tutorialOverlay').classList.remove('hidden')}
  cancelAnimationFrame(state.frameId);state.frameId=requestAnimationFrame(loop);
}
function preloadNext(){if(state.stage<10)loadImage(stageSrc(state.stage+1)).catch(()=>{});}

function calcArea(){let claimed=0,total=(GW-4)*(GH-4);for(let y=2;y<GH-2;y++)for(let x=2;x<GW-2;x++)if(getCell(x,y)===CLAIMED)claimed++;return claimed/total*100}

function captureRegion(){
  const before=state.area;
  for(let i=0;i<grid.length;i++)if(grid[i]===TRAIL)grid[i]=CLAIMED;
  const visited=new Uint8Array(grid.length), queue=new Int32Array(grid.length);let qh=0,qt=0;
  const push=(x,y)=>{if(!inGrid(x,y))return;const k=idx(x,y);if(!visited[k]&&grid[k]===UNCLAIMED){visited[k]=1;queue[qt++]=k}};
  for(const e of state.enemies){const c=cellAtPixel(e.x,e.y);push(c.x,c.y)}
  if(qt===0){const c=randomUnclaimedCell();push(c.x,c.y)}
  while(qh<qt){const k=queue[qh++],x=k%GW,y=(k/GW)|0;push(x+1,y);push(x-1,y);push(x,y+1);push(x,y-1)}
  let gained=0;
  for(let y=2;y<GH-2;y++)for(let x=2;x<GW-2;x++){const k=idx(x,y);if(grid[k]===UNCLAIMED&&!visited[k]){grid[k]=CLAIMED;gained++}}
  state.player.drawing=false;state.player.trailPath=[];rebuildVisualLayers();state.lastArea=before;state.area=calcArea();
  const delta=Math.max(0,state.area-before), points=Math.round(gained*(10+state.stage*2)*(1+Math.min(.8,delta/35)));
  state.score+=points;audio.beep(740,.09,'triangle',.04);if(delta>=12){audio.beep(980,.12,'sine',.03);toast(`BIG CAPTURE +${delta.toFixed(1)}% · +${fmtScore(points)}`)} else toast(`+${delta.toFixed(1)}% · +${fmtScore(points)}`);
  collectCapturedItems();maybeSpawnItem();updateHUD();checkMilestone();
}

function checkMilestone(){
  const a=state.area;
  if(a>=99&&state.clearMilestone<100){state.clearMilestone=100;unlockStage(state.stage);showClearModal(100);return}
  if(a>=90&&state.clearMilestone<90){state.clearMilestone=90;unlockStage(state.stage);showClearModal(90);return}
  if(a>=80&&state.clearMilestone<80){state.clearMilestone=80;unlockStage(state.stage);showClearModal(80)}
}

function showClearModal(level){
  state.paused=true;audio.setDanger(false);
  const perfect=level===100,bonus=level===90;
  const bonusPts=perfect?100000*state.stage:bonus?30000*state.stage:10000*state.stage;
  state.score+=bonusPts;updateHUD();
  audio.playJingle(perfect?'assets/audio/perfect.mp3':'assets/audio/clear.mp3');
  const title=perfect?'PERFECT!':bonus?'BONUS CLEAR!':'STAGE CLEAR!';
  const target=level===80?'90% BONUS':level===90?'PERFECT 100%':'';
  const continueBtn=!perfect?`<button id="keepBtn" class="btn secondary">KEEP PLAYING · ${target}</button>`:'';
  const artSrc=stageSrc(state.stage);
  openModal(`<div class="clear-review">
      <div class="clear-photo-wrap">
        <img id="clearPhoto" class="clear-photo" src="${artSrc}" alt="Stage ${state.stage} clear artwork" title="클릭해서 확대">
        <div class="clear-photo-badge">${title} · Stage ${state.stage} ${STAGES[state.stage].name}</div>
        <button id="clearZoomBtn" class="clear-zoom-btn" type="button" aria-label="클리어 이미지 확대">🔍 확대</button>
      </div>
      <div class="clear-review-bottom">
        <div class="clear-score">
          <div><small>AREA</small><strong>${state.area.toFixed(1)}%</strong></div>
          <div><small>BONUS</small><strong>+${fmtScore(bonusPts)}</strong></div>
          <div><small>SCORE</small><strong>${fmtScore(state.score)}</strong></div>
        </div>
        <div class="clear-actions">
          ${continueBtn}
          <button id="clearFeedbackBtn" class="btn tertiary clear-feedback-btn">💬 이 판 피드백</button>
          <button id="nextStageBtn" class="btn primary">${state.stage===10?'ENDING':'NEXT STAGE'}</button>
        </div>
      </div>
    </div>`, 'clear-review-card');
  track('stage_milestone',{stage:state.stage,area:state.area,milestone:level,score:state.score});
  $('#nextStageBtn').onclick=()=>{track('next_stage_click',{stage:state.stage,area:state.area});advanceStage()};
  $('#clearFeedbackBtn').onclick=()=>window.CMH_FEEDBACK?.show?.('stage_clear');
  const openZoom=()=>{track('clear_art_zoom',{stage:state.stage,area:state.area});showPhotoZoom(artSrc,`Stage ${state.stage} ${STAGES[state.stage].name}`)};
  $('#clearZoomBtn').onclick=openZoom;$('#clearPhoto').onclick=openZoom;
  if(!perfect)$('#keepBtn').onclick=()=>{track('keep_playing_click',{stage:state.stage,milestone:level});closeModal();state.paused=false;audio.resumeBase();toast(level===80?'90% 보너스를 노려보자!':'99%+ PERFECT를 노려보자!')};
}

function showPhotoZoom(src,label='Stage artwork'){
  const old=document.getElementById('photoLightbox');if(old)old.remove();
  const box=document.createElement('div');box.id='photoLightbox';box.className='photo-lightbox';box.setAttribute('role','dialog');box.setAttribute('aria-modal','true');box.setAttribute('aria-label','이미지 확대 보기');
  box.innerHTML=`<div class="photo-zoom-shell">
    <div class="photo-zoom-toolbar">
      <strong>${label}</strong><span id="photoZoomValue">100%</span>
      <button id="photoZoomOut" class="chip-btn" type="button" aria-label="축소">−</button>
      <button id="photoZoomIn" class="chip-btn" type="button" aria-label="확대">＋</button>
      <button id="photoZoomReset" class="chip-btn" type="button">RESET</button>
      <button id="photoZoomClose" class="chip-btn" type="button">✕</button>
    </div>
    <div id="photoZoomViewport" class="photo-zoom-viewport"><img id="photoZoomImage" src="${src}" alt="${label}"></div>
  </div>`;
  document.body.appendChild(box);
  const img=box.querySelector('#photoZoomImage'),view=box.querySelector('#photoZoomViewport'),val=box.querySelector('#photoZoomValue');
  let scale=1,tx=0,ty=0,drag=false,lastX=0,lastY=0;
  const clampPan=()=>{const maxX=view.clientWidth*Math.max(0,scale-1)/2,maxY=view.clientHeight*Math.max(0,scale-1)/2;tx=clamp(tx,-maxX,maxX);ty=clamp(ty,-maxY,maxY)};
  const apply=()=>{clampPan();img.style.transform=`translate(${tx}px,${ty}px) scale(${scale})`;val.textContent=`${Math.round(scale*100)}%`;view.classList.toggle('zoomed',scale>1.01)};
  const setScale=v=>{scale=clamp(v,1,4);if(scale===1){tx=0;ty=0}apply()};
  box.querySelector('#photoZoomIn').onclick=()=>setScale(scale+.25);
  box.querySelector('#photoZoomOut').onclick=()=>setScale(scale-.25);
  box.querySelector('#photoZoomReset').onclick=()=>setScale(1);
  const close=()=>box.remove();box.querySelector('#photoZoomClose').onclick=close;
  box.addEventListener('click',e=>{if(e.target===box)close()});
  view.addEventListener('wheel',e=>{e.preventDefault();setScale(scale+(e.deltaY<0?.2:-.2))},{passive:false});
  view.addEventListener('pointerdown',e=>{if(scale<=1)return;drag=true;lastX=e.clientX;lastY=e.clientY;view.setPointerCapture?.(e.pointerId)});
  view.addEventListener('pointermove',e=>{if(!drag)return;tx+=e.clientX-lastX;ty+=e.clientY-lastY;lastX=e.clientX;lastY=e.clientY;apply()});
  const stop=e=>{drag=false;try{view.releasePointerCapture?.(e.pointerId)}catch(_){}};view.addEventListener('pointerup',stop);view.addEventListener('pointercancel',stop);
  document.addEventListener('keydown',function esc(e){if(e.key==='Escape'&&document.getElementById('photoLightbox')){close();document.removeEventListener('keydown',esc)}});
  apply();
}

function advanceStage(){
  closeModal();saveGlobal();const cleared=state.stage;
  if(cleared>=10){saveToSlot(state.slot);return showEnding()}
  state.stage=cleared+1;state.lives=Math.max(1,state.lives);saveToSlot(state.slot);
  const planned=window.CMH_CONFIG?.ADS?.INTERSTITIAL_AFTER_STAGES||[2,4,6,8];
  const run=()=>startStage(state.stage,false);
  if(planned.includes(cleared))window.CMH_ADS?.showInterstitial?.(`after_stage_${cleared}`,run);else run();
}

function showEnding(){
  state.mode='ending';state.paused=true;unlockStage(10);saveGlobal({bestScore:Math.max(globalData().bestScore||0,state.score)});track('game_complete',{score:state.score});
  openModal(`<h2 class="ending-title">♥ ALL STAGES CLEAR ♥</h2><img class="ending-art" src="assets/images/stage10.webp" alt="Final Queen"><p style="text-align:center;font-size:1.2rem">FINAL SCORE <b>${fmtScore(state.score)}</b></p><div class="row"><button id="endingFeedback" class="btn tertiary">💬 FEEDBACK</button><button id="endingGallery" class="btn secondary">GALLERY</button><button id="endingTitle" class="btn primary">TITLE</button></div>`);
  $('#endingFeedback').onclick=()=>window.CMH_FEEDBACK?.show?.('game_complete');$('#endingGallery').onclick=showGallery;$('#endingTitle').onclick=showTitle;
}

function maybeSpawnItem(){if(state.items.length>=2||Math.random()>.34)return;const c=randomUnclaimedCell(12);const types=['speed','stop','bomb','shield'];state.items.push({x:c.x,y:c.y,type:types[Math.floor(Math.random()*types.length)]})}
function collectCapturedItems(){
  const left=[];for(const it of state.items){if(getCell(it.x,it.y)===CLAIMED)applyItem(it.type);else left.push(it)}state.items=left;
}
function applyItem(type){const t=now();if(type==='speed'){state.speedBoostUntil=t+9000;toast('⚡ SPEED UP 9s')}if(type==='stop'){state.freezeUntil=t+5500;toast('❄ BOSS STOP 5.5s')}if(type==='bomb'){state.projectiles=[];state.slowUntil=t+7500;toast('💣 BOMB · 적탄 제거 + SLOW')}if(type==='shield'){state.shield=Math.min(2,state.shield+1);toast('◆ SHIELD +1')}audio.beep(1120,.12,'sine',.04)}

function direction(){
  if(input.touchDir)return input.touchDir;
  const order=[input.lastDir,'up','down','left','right'].filter(Boolean);
  for(const d of order){if(input.dirs.has(d))return d}return null;
}
const input={dirs:new Set(),lastDir:null,capture:false,touchDir:null};
function dirVec(d){return d==='up'?[0,-1]:d==='down'?[0,1]:d==='left'?[-1,0]:d==='right'?[1,0]:[0,0]}

function movePlayer(){
  const d=direction();if(!d)return;
  const [dx,dy]=dirVec(d),p=state.player,nx=p.x+dx,ny=p.y+dy;
  if(!inGrid(nx,ny))return;
  const target=getCell(nx,ny), capture=input.capture;

  if(!p.drawing){
    if(target===CLAIMED){
      p.x=nx;p.y=ny;p.trailStart={x:nx,y:ny};p.trailPath=[];
    } else if(target===UNCLAIMED&&capture){
      p.drawing=true;p.trailStart={x:p.x,y:p.y};p.x=nx;p.y=ny;
      setCell(nx,ny,TRAIL);p.trailPath=[{x:nx,y:ny}];
      audio.beep(520,.06,'square',.025);
    }
    return;
  }

  // v0.2: allow deliberate backtracking along the immediately previous trail cells.
  // Crossing an older/non-adjacent part of the player's own trail is still a MISS.
  if(target===TRAIL){
    const path=p.trailPath||[];
    const prev=path.length>=2?path[path.length-2]:null;
    if(prev&&prev.x===nx&&prev.y===ny){
      setCell(p.x,p.y,UNCLAIMED);
      path.pop();p.x=nx;p.y=ny;
      audio.beep(390,.025,'square',.012);
      return;
    }
    failLife('자기 라인 교차');
    return;
  }

  // If the player retraces the very first trail cell back to the exact start point,
  // cancel the unfinished line instead of treating it as a capture or a death.
  if(target===CLAIMED && nx===p.trailStart.x && ny===p.trailStart.y && (p.trailPath?.length||0)===1){
    setCell(p.x,p.y,UNCLAIMED);
    p.x=nx;p.y=ny;p.drawing=false;p.trailPath=[];
    audio.beep(330,.05,'triangle',.018);toast('라인 취소');
    return;
  }

  p.x=nx;p.y=ny;
  if(target===UNCLAIMED){
    setCell(nx,ny,TRAIL);p.trailPath.push({x:nx,y:ny});
  } else if(target===CLAIMED){
    captureRegion();
  }
}
function failLife(reason='MISS'){
  if(state.mode!=='playing'||state.paused)return;
  if(state.shield>0){state.shield--;clearTrail();toast(`◆ SHIELD! ${reason}`,true);audio.beep(260,.14,'sawtooth',.04);return}
  state.lives--;clearTrail();state.projectiles=[];audio.beep(150,.25,'sawtooth',.05);toast(`MISS · ${reason}`,true,1800);updateHUD();track('life_lost',{stage:state.stage,reason,lives:state.lives});
  if(state.lives<=0)showGameOver();
}
function clearTrail(){for(let i=0;i<grid.length;i++)if(grid[i]===TRAIL)grid[i]=UNCLAIMED;const p=state.player;p.x=p.trailStart.x;p.y=p.trailStart.y;p.drawing=false;p.trailPath=[];rebuildVisualLayers()}

function showGameOver(){
  state.paused=true;audio.setDanger(false);saveGlobal();track('game_over',{stage:state.stage,score:state.score});
  const adEnabled=window.CMH_ADS?.enabled?.();
  const continueButton=adEnabled?'<button id="rewardContinue" class="btn secondary">WATCH AD · LIFE +1</button>':state.continueCredits>0?'<button id="freeContinue" class="btn secondary">CONTINUE · TEST CREDIT</button>':'';
  openModal(`<div class="game-over-title">GAME OVER</div><p style="text-align:center">Stage ${state.stage} · ${fmtScore(state.score)} pts</p><div class="slot-grid">${continueButton}<button id="gameoverFeedback" class="btn tertiary">💬 한줄 피드백</button><button id="gameoverLoad" class="btn tertiary">LOAD SAVE</button><button id="gameoverTitle" class="btn primary">TITLE</button></div>`);
  if($('#freeContinue'))$('#freeContinue').onclick=()=>{state.continueCredits--;state.lives=1;closeModal();startStage(state.stage,true)};
  if($('#rewardContinue'))$('#rewardContinue').onclick=async()=>{const ok=await window.CMH_ADS.showRewardedLife();if(ok){state.lives=1;closeModal();startStage(state.stage,true)}else toast('광고가 완료되지 않았습니다',true)};
  $('#gameoverFeedback').onclick=()=>window.CMH_FEEDBACK?.show?.('game_over');$('#gameoverLoad').onclick=()=>showSlotPicker('load');$('#gameoverTitle').onclick=showTitle;
}

function updateEnemies(dt){
  const cfg=STAGES[state.stage], frozen=now()<state.freezeUntil, slow=now()<state.slowUntil;
  if(frozen)return;
  for(const e of state.enemies){
    const speed=e.speed*(slow ? 0.55 : 1);
    if(state.player.drawing&&e.chase>0){const tx=(state.player.x+.5)*CELL,ty=(state.player.y+.5)*CELL,dx=tx-e.x,dy=ty-e.y,len=Math.hypot(dx,dy)||1;const tvx=dx/len*speed,tvy=dy/len*speed;e.vx=e.vx*(1-e.chase)+tvx*e.chase;e.vy=e.vy*(1-e.chase)+tvy*e.chase;const vl=Math.hypot(e.vx,e.vy)||1;e.vx=e.vx/vl*speed;e.vy=e.vy/vl*speed}
    let nx=e.x+e.vx*dt,ny=e.y+e.vy*dt;let c=cellAtPixel(nx,e.y),cell=getCell(c.x,c.y);if(cell===TRAIL){failLife('보스가 라인을 끊었습니다');return}if(cell===CLAIMED){e.vx*=-1;nx=e.x+e.vx*dt}
    c=cellAtPixel(e.x,ny);cell=getCell(c.x,c.y);if(cell===TRAIL){failLife('보스가 라인을 끊었습니다');return}if(cell===CLAIMED){e.vy*=-1;ny=e.y+e.vy*dt}
    e.x=clamp(nx,CELL*2.5,W-CELL*2.5);e.y=clamp(ny,CELL*2.5,H-CELL*2.5);
    if(state.player.drawing&&dist(e.x,e.y,(state.player.x+.5)*CELL,(state.player.y+.5)*CELL)<e.r+8){failLife('보스 충돌');return}
    if(e.isBoss&&cfg.shots){e.shotTimer-=dt*1000;if(e.shotTimer<=0){e.shotTimer=cfg.shots*(.8+Math.random()*.45);shoot(e)}}
  }
}
function shoot(e){
  const px=(state.player.x+.5)*CELL,py=(state.player.y+.5)*CELL,dx=px-e.x,dy=py-e.y,len=Math.hypot(dx,dy)||1,s=150+state.stage*8;state.projectiles.push({x:e.x,y:e.y,vx:dx/len*s,vy:dy/len*s,r:4});if(state.stage>=7&&Math.random()<.32){const ang=Math.atan2(dy,dx)+(.3*(Math.random()>.5?1:-1));state.projectiles.push({x:e.x,y:e.y,vx:Math.cos(ang)*s,vy:Math.sin(ang)*s,r:3})}
}
function updateProjectiles(dt){
  const next=[];for(const p of state.projectiles){p.x+=p.vx*dt;p.y+=p.vy*dt;if(p.x<0||p.y<0||p.x>=W||p.y>=H)continue;const c=cellAtPixel(p.x,p.y),cell=getCell(c.x,c.y);if(cell===CLAIMED)continue;if(cell===TRAIL){failLife('적탄이 라인을 맞췄습니다');return}if(state.player.drawing&&dist(p.x,p.y,(state.player.x+.5)*CELL,(state.player.y+.5)*CELL)<10){failLife('적탄 충돌');return}next.push(p)}state.projectiles=next;
}

function dangerCheck(){
  if(!state.player.drawing)return state.timeLeft<20;
  const px=(state.player.x+.5)*CELL,py=(state.player.y+.5)*CELL;let nearest=9999;for(const e of state.enemies)nearest=Math.min(nearest,dist(px,py,e.x,e.y));return nearest<150||state.timeLeft<25;
}

function cameraRect(){
  const zoom=clamp(Number(window.CMH_CONFIG?.GAMEPLAY?.CAMERA_ZOOM)||1.50,1,2.25);
  const sw=W/zoom,sh=H/zoom;
  const px=(state.player.x+.5)*CELL,py=(state.player.y+.5)*CELL;
  const sx=clamp(px-sw/2,0,W-sw),sy=clamp(py-sh/2,0,H-sh);
  return {sx,sy,sw,sh,zoom};
}

function drawWorld(c){
  c.fillStyle='#000';c.fillRect(0,0,W,H);if(state.currentImage)c.drawImage(state.currentImage,0,0,W,H);c.drawImage(fogCanvas,0,0);c.drawImage(safeCanvas,0,0);
  // trail
  c.save();c.shadowBlur=12;c.shadowColor='#ff4fa3';c.fillStyle='#ff65b2';for(let y=0;y<GH;y++)for(let x=0;x<GW;x++)if(getCell(x,y)===TRAIL)c.fillRect(x*CELL+1,y*CELL+1,CELL-2,CELL-2);c.restore();
  // items
  for(const it of state.items){const x=(it.x+.5)*CELL,y=(it.y+.5)*CELL;c.save();c.shadowBlur=12;c.shadowColor='#ffe36e';c.fillStyle='rgba(10,6,20,.8)';c.beginPath();c.arc(x,y,11,0,Math.PI*2);c.fill();c.strokeStyle='#ffe36e';c.stroke();c.fillStyle='#fff';c.font='bold 12px system-ui';c.textAlign='center';c.textBaseline='middle';c.fillText(it.type==='speed'?'⚡':it.type==='stop'?'❄':it.type==='bomb'?'✹':'◆',x,y);c.restore()}
  // projectiles
  for(const p of state.projectiles){c.save();c.shadowBlur=12;c.shadowColor='#ff4b70';c.fillStyle='#ff5574';c.beginPath();c.arc(p.x,p.y,p.r,0,Math.PI*2);c.fill();c.restore()}
  // enemies
  state.enemies.forEach(e=>{c.save();c.translate(e.x,e.y);c.shadowBlur=e.isBoss?20:12;c.shadowColor=e.isBoss?STAGES[state.stage].hue:'#ff6d83';c.strokeStyle=e.isBoss?'#fff':'#ffd2da';c.fillStyle=e.isBoss?STAGES[state.stage].hue:'#df4966';c.lineWidth=2;c.beginPath();const points=e.isBoss?8:6;for(let k=0;k<points;k++){const a=k/points*Math.PI*2,r=e.r*(k%2?0.55:1);const xx=Math.cos(a)*r,yy=Math.sin(a)*r;k?c.lineTo(xx,yy):c.moveTo(xx,yy)}c.closePath();c.fill();c.stroke();c.restore()});
  // player
  const p=state.player,px=(p.x+.5)*CELL,py=(p.y+.5)*CELL;c.save();c.shadowBlur=16;c.shadowColor=p.drawing?'#ff55ab':'#52efff';c.fillStyle=p.drawing?'#fff0f9':'#e7fdff';c.strokeStyle=p.drawing?'#ff4fa3':'#42dff5';c.lineWidth=3;c.beginPath();c.arc(px,py,6.5,0,Math.PI*2);c.fill();c.stroke();if(state.shield){c.strokeStyle='#ffe36c';c.beginPath();c.arc(px,py,11,0,Math.PI*2);c.stroke()}c.restore();
}

function renderMiniMap(cam){
  if(!miniCtx||window.CMH_CONFIG?.GAMEPLAY?.MINIMAP_ENABLED===false)return;
  const mw=miniMap.width,mh=miniMap.height;
  miniCtx.fillStyle='#08040c';miniCtx.fillRect(0,0,mw,mh);
  miniCtx.drawImage(worldCanvas,0,0,mw,mh);
  miniCtx.fillStyle='rgba(4,2,9,.18)';miniCtx.fillRect(0,0,mw,mh);
  const sx=mw/W,sy=mh/H;
  // Camera window
  miniCtx.save();miniCtx.strokeStyle='rgba(255,255,255,.95)';miniCtx.lineWidth=2;miniCtx.shadowBlur=8;miniCtx.shadowColor='#ff55a8';miniCtx.strokeRect(cam.sx*sx+.5,cam.sy*sy+.5,cam.sw*sx-1,cam.sh*sy-1);miniCtx.restore();
  // Keep key actors readable even when artwork is busy.
  const pp=state.player;miniCtx.fillStyle='#fff';miniCtx.strokeStyle='#32dfff';miniCtx.lineWidth=2;miniCtx.beginPath();miniCtx.arc((pp.x+.5)*CELL*sx,(pp.y+.5)*CELL*sy,4.5,0,Math.PI*2);miniCtx.fill();miniCtx.stroke();
  state.enemies.forEach(e=>{miniCtx.fillStyle=e.isBoss?'#ff405f':'#ff91a4';miniCtx.beginPath();miniCtx.arc(e.x*sx,e.y*sy,e.isBoss?4.5:3,0,Math.PI*2);miniCtx.fill()});
  miniCtx.strokeStyle='rgba(255,255,255,.75)';miniCtx.lineWidth=2;miniCtx.strokeRect(1,1,mw-2,mh-2);
}

function render(){
  drawWorld(worldCtx);
  const cam=cameraRect();
  ctx.fillStyle='#000';ctx.fillRect(0,0,W,H);
  ctx.imageSmoothingEnabled=true;
  ctx.drawImage(worldCanvas,cam.sx,cam.sy,cam.sw,cam.sh,0,0,W,H);
  // Main-view edge vignette makes the tighter camera feel intentional.
  const g=ctx.createRadialGradient(W/2,H/2,Math.min(W,H)*.28,W/2,H/2,Math.max(W,H)*.68);g.addColorStop(0,'rgba(0,0,0,0)');g.addColorStop(1,'rgba(0,0,0,.18)');ctx.fillStyle=g;ctx.fillRect(0,0,W,H);
  if(dangerCheck()){ctx.save();ctx.font='900 30px system-ui';ctx.textAlign='center';ctx.fillStyle='rgba(255,80,100,.94)';ctx.shadowBlur=16;ctx.shadowColor='#ff334e';ctx.fillText('DANGER!',W/2,48);ctx.restore()}
  renderMiniMap(cam);
}

function updateHUD(){
  $('#stageLabel').textContent=`${state.stage} · ${STAGES[state.stage]?.name||''}`;$('#scoreLabel').textContent=fmtScore(state.score);$('#areaLabel').textContent=`${state.area.toFixed(1)}%`;$('#timeLabel').textContent=Math.max(0,Math.ceil(state.timeLeft));$('#lifeLabel').textContent='♥'.repeat(Math.max(0,state.lives))+(state.shield?` ◆${state.shield}`:'');$('#progressBar').style.width=`${Math.min(100,state.area)}%`;updateMusicLabel();
}
function updateMusicLabel(){const label=$('#musicLabel');if(!label)return;label.textContent=`${audio.muted?'🔇':'♫'} ${state.mode==='playing'?STAGES[state.stage]?.name:'Capture My Heart!'}`}

function loop(ts){
  if(state.mode!=='playing'){render();return}
  const dt=Math.min(.04,Math.max(0,(ts-state.lastTs)/1000||0));state.lastTs=ts;
  if(!state.paused&&!state.adPaused){
    const moveInterval=(now()<state.speedBoostUntil?0.038:0.058);state.moveAcc+=dt;while(state.moveAcc>=moveInterval){movePlayer();state.moveAcc-=moveInterval;if(state.paused)break}
    if(!state.paused){updateEnemies(dt);updateProjectiles(dt);state.timerAcc+=dt;if(state.timerAcc>=.1){state.timeLeft-=state.timerAcc;state.timerAcc=0;if(state.timeLeft<=0){state.timeLeft=STAGES[state.stage].timer;failLife('TIME UP')}}const danger=dangerCheck();if(window.CMH_CONFIG?.GAMEPLAY?.DANGER_BGM_ENABLED!==false)audio.setDanger(danger)}
  }
  render();updateHUD();state.frameId=requestAnimationFrame(loop);
}

function pauseForAd(){state.adPaused=true;state.paused=true}
function resumeAfterAd(){state.adPaused=false;state.paused=false;state.lastTs=performance.now();audio.resumeBase()}
function showRewardPrompt(showAdFn){
  const box=$('#rewardPrompt');box.classList.remove('hidden');$('#rewardWatchBtn').onclick=()=>{box.classList.add('hidden');showAdFn()};$('#rewardCancelBtn').onclick=()=>box.classList.add('hidden');
}

// Input wiring
const keyMap={ArrowUp:'up',KeyW:'up',ArrowDown:'down',KeyS:'down',ArrowLeft:'left',KeyA:'left',ArrowRight:'right',KeyD:'right'};
window.addEventListener('keydown',e=>{if(keyMap[e.code]){input.dirs.add(keyMap[e.code]);input.lastDir=keyMap[e.code];if(state.mode==='playing')e.preventDefault()}if(e.code==='Space'){input.capture=true;if(state.mode==='playing')e.preventDefault()}if(e.code==='Escape'&&state.mode==='playing'&&!state.paused)showPause()});
window.addEventListener('keyup',e=>{if(keyMap[e.code])input.dirs.delete(keyMap[e.code]);if(e.code==='Space')input.capture=false});
window.addEventListener('blur',()=>{input.dirs.clear();input.capture=false;if(state.mode==='playing'&&!state.paused)showPause()});

document.querySelectorAll('.dkey').forEach(b=>{const dir=b.dataset.dir;const down=e=>{e.preventDefault();input.touchDir=dir;b.classList.add('active')};const up=e=>{e.preventDefault();if(input.touchDir===dir)input.touchDir=null;b.classList.remove('active')};b.addEventListener('pointerdown',down);b.addEventListener('pointerup',up);b.addEventListener('pointercancel',up);b.addEventListener('pointerleave',up)});
const cap=$('#captureTouchBtn');cap.addEventListener('pointerdown',e=>{e.preventDefault();input.capture=true;cap.classList.add('active')});['pointerup','pointercancel','pointerleave'].forEach(ev=>cap.addEventListener(ev,e=>{e.preventDefault();input.capture=false;cap.classList.remove('active')}));

$('#newGameBtn').onclick=()=>showSlotPicker('new');$('#continueBtn').onclick=()=>{const r=recentSave();if(r)loadSaveData(r)};$('#loadBtn').onclick=()=>showSlotPicker('load');$('#galleryBtn').onclick=showGallery;$('#settingsBtn').onclick=showSettings;$('#howToBtn').onclick=showHowTo;$('#feedbackBtn').onclick=()=>window.CMH_FEEDBACK?.show?.('title');$('#pauseBtn').onclick=showPause;
$('#tutorialOkBtn').onclick=()=>{$('#tutorialOverlay').classList.add('hidden');state.tutorialShown=true;localStorage.setItem('cmh.tutorial','1');state.paused=false;audio.resumeBase()};

function ageGate(){const gate=$('#ageGate');if(localStorage.getItem('cmh.age')==='1'){gate.classList.add('hidden');return}gate.classList.remove('hidden');$('#ageConfirmBtn').onclick=()=>{localStorage.setItem('cmh.age','1');gate.classList.add('hidden');audio.playTitle()}}
function registerSW(){if('serviceWorker'in navigator&&location.protocol.startsWith('http'))navigator.serviceWorker.register('sw.js').catch(()=>{})}

window.CMH_GAME={audio,pauseForAd,resumeAfterAd,showRewardPrompt,state};
loadUnlocked();refreshTitle();ageGate();initAnalytics();window.CMH_ADS?.init?.();registerSW();updateMusicLabel();
let firstGesture=false;document.addEventListener('pointerdown',()=>{if(!firstGesture){firstGesture=true;if(state.mode==='title')audio.playTitle()}},{once:true});
})();
