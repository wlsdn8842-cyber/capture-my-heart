window.CMH_CONFIG = {
  GAME_TITLE: 'Capture My Heart! Territory Panic',
  VERSION: '0.5.1',
  GAMEPLAY: {
    DANGER_BGM_ENABLED: false,
    DANGER_VISUAL_ENABLED: true,
    CAMERA_ZOOM: 1.50,
    MINIMAP_ENABLED: true
  },
  ADS: {
    ENABLED: false,
    PUBLISHER_ID: '', // 실제 H5 Games Ads 승인 후: ca-pub-xxxxxxxxxxxxxxxx
    TEST_MODE: false, // Publisher ID 입력 후 true면 Google의 가짜 광고로 배치 테스트
    FREQUENCY_HINT: '120s',
    INTERSTITIAL_AFTER_STAGES: [2, 4, 6, 8],
    MIN_SECONDS_BETWEEN_INTERSTITIALS: 120
  },
  FEEDBACK: {
    ENABLED: true,
    ENDPOINT: '/api/feedback', // Cloudflare Pages Function + D1. 로컬에서는 전송 실패 시 자동 큐 저장.
    REQUEST_TIMEOUT_MS: 6500,
    MAX_LOCAL_QUEUE: 50
  },
  ANALYTICS: {
    GA_MEASUREMENT_ID: '' // 예: G-XXXXXXXXXX
  }
};
